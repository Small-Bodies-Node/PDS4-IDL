#!/bin/csh
(/usr/local/bin/idl < inpro >! outtxt) >& /dev/null
sed -e 's#/home/eshaya/Documents/idl/pro/\(.*\))#<A href="\1">\1</A>)#' index.html >! out.html
echo 'overwrite index.html?'
yes | cp -v -i out.html index.html
grep home index.html
cd ..
tar -chf PDS/pds4readxml.tar PDS/*.pro PDS/*.txt PDS/browse/*.pro
cd PDS
scp pds4readxml.tar index.html gaia:public_html/PDS
ssh gaia 'cd public_html/PDS ; tar -xvf pds4readxml.tar'
