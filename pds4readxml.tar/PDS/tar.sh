#!/bin/csh
sed -e 's#/home/eshaya/Documents/idl/pro/\(.*\))#<A href="\1">\1</A>)#' index.html >! out.html
cp out.html index.html
cd ..
tar -cvf PDS/pds4readxml.tar PDS/*.pro PDS/*.txt PDS/browse/*.pro
cd PDS
scp pds4readxml.tar gaia:public_html/PDS
scp index.html gaia:public_html/PDS
